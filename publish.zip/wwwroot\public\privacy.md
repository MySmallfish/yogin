# Privacy Policy

We respect your privacy and only use your data to operate the studio.

## What we collect
- Contact details you provide (name, email, phone, address).
- Booking history and attendance records.
- Health waiver information you submit.

## How we use it
- To manage your account and bookings.
- To communicate about classes, updates, and payments.
- To meet studio safety and compliance needs.

## Data retention
Studios may export or delete records periodically.

## Contact
If you have questions, reach out to the studio.
