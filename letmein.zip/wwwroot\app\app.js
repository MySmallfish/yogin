﻿import { createMachine, createActor, fromPromise, assign } from "xstate";
import { apiGet, apiPost, apiPut } from "../shared/api.js";
import { login, logout, register, getSession, loadSessionHint } from "../shared/auth.js";
import { compileTemplate } from "../shared/templates.js";
import { formatDateTime, formatMoney, getQueryParam } from "../shared/utils.js";

const root = document.getElementById("app");
const sessionHint = loadSessionHint();

const layoutTemplate = compileTemplate("layout", `
  <div class="shell">
    <div class="hero">
      <h1>{{title}}</h1>
      <div class="meta">{{subtitle}}</div>
    </div>
    <nav class="navbar">
      <a href="#/schedule" data-route="schedule">Schedule</a>
      <a href="#/me" data-route="me">My registrations</a>
      <a href="#/payments" data-route="payments">Payments</a>
      <a href="#/profile" data-route="profile">Profile</a>
      <button class="secondary" id="logout-btn">Log out</button>
    </nav>
    <div class="surface">
      {{{content}}}
    </div>
  </div>
`);

const loginTemplate = compileTemplate("login", `
  <div class="login-card">
    <h2>Welcome to Letmein</h2>
    <p>Sign in or create an account to register for classes.</p>
    {{#if error}}
      <div class="notice">{{error}}</div>
    {{/if}}
    <div class="login-switch">
      <button type="button" class="secondary active" data-auth-mode="login">Sign in</button>
      <button type="button" class="secondary" data-auth-mode="register">Create account</button>
    </div>
    <form id="login-form">
      <label>Email</label>
      <input type="email" name="email" required value="member@letmein.local" />
      <label>Password</label>
      <input type="password" name="password" required value="member123" />
      <label>Studio slug</label>
      <input type="text" name="studioSlug" required value="{{studioSlug}}" />
      <button type="submit">Sign in</button>
    </form>
    <form id="register-form" class="hidden">
      <label>Full name</label>
      <input type="text" name="fullName" required />
      <label>Phone</label>
      <input type="tel" name="phone" />
      <label>Email</label>
      <input type="email" name="email" required />
      <label>Password</label>
      <input type="password" name="password" required />
      <label>Studio slug</label>
      <input type="text" name="studioSlug" required value="{{studioSlug}}" />
      <button type="submit">Create account</button>
    </form>
  </div>
`);

const scheduleTemplate = compileTemplate("schedule", `
  {{#if notice}}
    <div class="notice">{{notice}}</div>
  {{/if}}
  {{#if hasItems}}
    {{#each sections}}
      <div class="schedule-day">
        <div class="schedule-day-header">{{label}}</div>
        <div class="grid">
          {{#each items}}
          <div class="card {{#if isFull}}dim{{/if}}">
            <h3>{{seriesTitle}}</h3>
            <div class="meta">{{start}} - {{roomName}}</div>
            <div class="meta">Instructor: {{instructorName}}</div>
            <div class="meta">{{availability}}</div>
            <div class="meta">{{price}}</div>
            <button data-event="{{id}}" {{#unless isBookable}}disabled{{/unless}}>{{ctaLabel}}</button>
          </div>
          {{/each}}
        </div>
      </div>
    {{/each}}
  {{else}}
    <div class="empty-state">No upcoming classes yet.</div>
  {{/if}}
`);

const eventTemplate = compileTemplate("event", `
  <div class="event-layout">
    <div class="card">
      <div class="event-header">
        <h3>{{seriesTitle}}</h3>
        <span class="pill {{statusClass}}">{{statusLabel}}</span>
      </div>
      <div class="meta">{{start}} - {{roomName}}</div>
      <div class="meta">{{description}}</div>
      <div class="meta">Instructor: {{instructorName}}</div>
      <div class="meta">{{availability}}</div>
      <div class="meta">{{price}}</div>
    </div>
    <div class="card">
      <h3>Book your spot</h3>
      {{#if error}}
        <div class="notice">{{error}}</div>
      {{/if}}
      {{#if notice}}
        <div class="notice">{{notice}}</div>
      {{/if}}
      <label>Use membership</label>
      <select id="membership-select">
        <option value="">Drop-in</option>
        {{#each memberships}}
          <option value="{{id}}">{{label}}</option>
        {{/each}}
      </select>
      <button id="book-btn" {{#unless isBookable}}disabled{{/unless}}>{{bookLabel}}</button>
      {{#if hasPlans}}
        <div class="plan-list">
          <h4>Need a pass?</h4>
          <div class="plan-grid">
            {{#each plans}}
              <div class="plan-card">
                <div class="plan-name">{{name}}</div>
                <div class="meta">{{price}}</div>
                <button class="secondary" data-plan="{{id}}">Buy pass</button>
              </div>
            {{/each}}
          </div>
        </div>
      {{/if}}
    </div>
  </div>
`);

const bookingsTemplate = compileTemplate("bookings", `
  {{#if notice}}
    <div class="notice">{{notice}}</div>
  {{/if}}
  <div class="grid">
    {{#each bookings}}
    <div class="card">
      <h3>{{title}}</h3>
      <div class="meta">{{start}}</div>
      <div class="meta">Status: {{status}}</div>
      {{#if canCancel}}
        <button class="secondary" data-cancel="{{id}}">Cancel</button>
      {{/if}}
    </div>
    {{/each}}
  </div>
`);

const paymentsTemplate = compileTemplate("payments", `
  <div class="grid">
    {{#each payments}}
    <div class="card">
      <h3>{{amount}}</h3>
      <div class="meta">Status: {{status}}</div>
      <div class="meta">{{date}}</div>
      <div class="meta">Provider: {{provider}}</div>
    </div>
    {{/each}}
  </div>
`);

const profileTemplate = compileTemplate("profile", `
  <form id="profile-form">
    <label>Full name</label>
    <input name="fullName" value="{{fullName}}" />
    <label>Phone</label>
    <input name="phone" value="{{phone}}" />
    <button type="submit">Save profile</button>
  </form>
  <div style="margin-top:20px;">
    <h3>Health declaration</h3>
    <p class="meta">Required before first booking.</p>
    <form id="health-form">
      <label>Signature</label>
      <input name="signatureName" value="{{fullName}}" />
      <input type="hidden" name="payloadJson" value='{"acknowledged":true}' />
      <button type="submit">Submit declaration</button>
    </form>
  </div>
`);

const appMachine = createMachine({
    id: "app",
    initial: "boot",
    context: {
        user: null,
        studioSlug: getQueryParam("studio") || sessionHint.studioSlug || "demo",
        route: "schedule",
        params: {},
        data: {},
        error: ""
    },
    states: {
        boot: {
            invoke: {
                src: "loadSession",
                onDone: {
                    target: "loading",
                    actions: "setSession"
                },
                onError: {
                    target: "login"
                }
            }
        },
        login: {
            on: {
                LOGIN_SUCCESS: {
                    target: "loading",
                    actions: "setSession"
                }
            }
        },
        loading: {
            invoke: {
                src: "loadRoute",
                input: ({ context }) => context,
                onDone: {
                    target: "ready",
                    actions: "setData"
                },
                onError: {
                    target: "ready",
                    actions: "setError"
                }
            }
        },
        ready: {
            on: {
                NAVIGATE: {
                    target: "loading",
                    actions: "setRoute"
                },
                REFRESH: {
                    target: "loading"
                }
            }
        }
    }
}, {
    actions: {
        setSession: assign(({ context, event }) => {
            const payload = event.output ?? event;
            return {
                ...context,
                user: payload.user ?? context.user,
                studioSlug: payload.studio?.slug ?? context.studioSlug,
                error: ""
            };
        }),
        setRoute: assign(({ context, event }) => ({
            ...context,
            route: event.route,
            params: event.params || {}
        })),
        setData: assign(({ context, event }) => ({
            ...context,
            data: event.output,
            error: ""
        })),
        setError: assign(({ context, event }) => ({
            ...context,
            error: event.error?.message || "Unable to load data"
        }))
    },
    actors: {
        loadSession: fromPromise(async () => {
            const session = await getSession();
            return { user: session.user };
        }),
        loadRoute: fromPromise(async ({ input }) => {
            switch (input.route) {
                case "schedule": {
                    const from = new Date().toISOString().slice(0, 10);
                    const toDate = new Date();
                    toDate.setDate(toDate.getDate() + 14);
                    const to = toDate.toISOString().slice(0, 10);
                    const items = await apiGet(`/api/public/studios/${input.studioSlug}/schedule?from=${from}&to=${to}`);
                    return { items };
                }
                case "event": {
                    const event = await apiGet(`/api/public/studios/${input.studioSlug}/event-instances/${input.params.id}`);
                    const memberships = await apiGet("/api/app/me/memberships");
                    const plans = await apiGet(`/api/public/studios/${input.studioSlug}/plans`);
                    return { event, memberships, plans };
                }
                case "me": {
                    const bookings = await apiGet("/api/app/me/bookings");
                    return { bookings };
                }
                case "payments": {
                    const payments = await apiGet("/api/app/me/payments");
                    return { payments };
                }
                case "profile": {
                    const profile = await apiGet("/api/app/me/profile");
                    return { profile };
                }
                default:
                    return {};
            }
        })
    }
});

const actor = createActor(appMachine);

function render(state) {
    if (state.matches("login")) {
        root.innerHTML = loginTemplate({ error: state.context.error, studioSlug: state.context.studioSlug });
        bindAuthForms();
        return;
    }

    const route = state.context.route;
    const notice = getQueryParam("notice");
    const titleMap = {
        schedule: "Your studio schedule",
        event: "Class details",
        me: "My registrations",
        payments: "Payments",
        profile: "Profile"
    };

    let content = "";
    const data = state.context.data || {};

    if (route === "schedule") {
        const items = (data.items || []).map(item => {
            const statusLabel = normalizeStatus(item.status);
            const isBookable = statusLabel === "Scheduled" && item.available > 0;
            const ctaLabel = statusLabel === "Cancelled"
                ? "Cancelled"
                : item.available > 0
                    ? "Register"
                    : "Full";
            const dateKey = toDateKeyLocal(item.startUtc);
            return {
                ...item,
                dateKey,
                dateLabel: formatDateLabel(item.startUtc),
                start: formatDateTime(item.startUtc),
                availability: `${item.available} spots left`,
                price: formatMoney(item.priceCents, item.currency),
                isBookable,
                isFull: !isBookable,
                ctaLabel
            };
        });
        const sections = groupScheduleItems(items);
        content = scheduleTemplate({
            sections,
            hasItems: sections.length > 0,
            notice: notice === "cancelled" ? "Booking cancelled." : ""
        });
    }

    if (route === "event") {
        const event = data.event || {};
        const statusLabel = normalizeStatus(event.status);
        const available = event.available ?? Math.max(0, (event.capacity || 0) - (event.booked || 0));
        const isBookable = statusLabel === "Scheduled" && available > 0;
        const bookingNotice = statusLabel === "Cancelled"
            ? "This class has been cancelled."
            : available <= 0
                ? "This class is currently full."
                : "";
        const memberships = (data.memberships || []).map(membership => ({
            ...membership,
            label: buildMembershipLabel(membership)
        }));
        const plans = (data.plans || []).map(plan => ({
            ...plan,
            price: formatMoney(plan.priceCents, plan.currency)
        }));
        content = eventTemplate({
            ...event,
            start: formatDateTime(event.startUtc),
            availability: `${available} spots left`,
            price: formatMoney(event.priceCents, event.currency),
            memberships,
            plans,
            hasPlans: plans.length > 0,
            isBookable,
            bookLabel: isBookable ? "Register now" : "Not available",
            statusLabel,
            statusClass: statusLabel === "Cancelled" ? "pill-muted" : "pill-live",
            notice: bookingNotice,
            error: state.context.error
        });
    }

    if (route === "me") {
        const bookings = (data.bookings || []).map(booking => ({
            id: booking.id,
            status: booking.status,
            title: booking.instance?.seriesTitle || "Class",
            start: formatDateTime(booking.instance?.startUtc),
            canCancel: booking.status === "Confirmed" || booking.status === 1
        }));
        content = bookingsTemplate({
            bookings,
            notice: notice === "booked"
                ? "Booking confirmed."
                : notice === "cancelled"
                    ? "Booking cancelled."
                    : ""
        });
    }

    if (route === "payments") {
        const payments = (data.payments || []).map(payment => ({
            amount: formatMoney(payment.amountCents, payment.currency),
            status: payment.status,
            date: formatDateTime(payment.createdAtUtc),
            provider: payment.provider
        }));
        content = paymentsTemplate({ payments });
    }

    if (route === "profile") {
        const profile = data.profile || {};
        content = profileTemplate(profile);
    }

    root.innerHTML = layoutTemplate({
        title: titleMap[route] || "Letmein",
        subtitle: "Reserve your next session",
        content
    });

    document.querySelectorAll(".navbar a").forEach(link => {
        const routeName = link.getAttribute("data-route");
        if (routeName === route) {
            link.classList.add("active");
        }
    });

    const logoutBtn = document.getElementById("logout-btn");
    if (logoutBtn) {
        logoutBtn.addEventListener("click", async () => {
            await logout();
            window.location.reload();
        });
    }

    bindRouteActions(route, data);
}

function bindAuthForms(defaultMode = "login") {
    const loginForm = document.getElementById("login-form");
    const registerForm = document.getElementById("register-form");
    const modeButtons = document.querySelectorAll("[data-auth-mode]");

    if (!loginForm || !registerForm) return;

    const setMode = (mode) => {
        const isRegister = mode === "register";
        loginForm.classList.toggle("hidden", isRegister);
        registerForm.classList.toggle("hidden", !isRegister);
        modeButtons.forEach(btn => {
            const buttonMode = btn.getAttribute("data-auth-mode");
            btn.classList.toggle("active", buttonMode === mode);
        });
    };

    modeButtons.forEach(btn => {
        btn.addEventListener("click", () => {
            const mode = btn.getAttribute("data-auth-mode") || "login";
            setMode(mode);
        });
    });

    loginForm.addEventListener("submit", async (event) => {
        event.preventDefault();
        const formData = new FormData(loginForm);
        const payload = {
            email: formData.get("email"),
            password: formData.get("password"),
            role: "customer",
            studioSlug: formData.get("studioSlug")
        };
        try {
            const result = await login(payload);
            actor.send({ type: "LOGIN_SUCCESS", output: result });
        } catch (error) {
            root.innerHTML = loginTemplate({ error: error.message, studioSlug: payload.studioSlug });
            bindAuthForms("login");
        }
    });

    registerForm.addEventListener("submit", async (event) => {
        event.preventDefault();
        const formData = new FormData(registerForm);
        const payload = {
            fullName: formData.get("fullName"),
            phone: formData.get("phone"),
            email: formData.get("email"),
            password: formData.get("password"),
            studioSlug: formData.get("studioSlug")
        };
        try {
            const result = await register(payload);
            actor.send({ type: "LOGIN_SUCCESS", output: result });
        } catch (error) {
            root.innerHTML = loginTemplate({ error: error.message, studioSlug: payload.studioSlug });
            bindAuthForms("register");
        }
    });

    setMode(defaultMode);
}

function bindRouteActions(route, data) {
    if (route === "schedule")
    {
        document.querySelectorAll("button[data-event]").forEach(btn => {
            btn.addEventListener("click", () => {
                const id = btn.getAttribute("data-event");
                window.location.hash = `#/event/${id}`;
            });
        });
    }

    if (route === "event")
    {
        const button = document.getElementById("book-btn");
        if (button) {
            button.addEventListener("click", async () => {
                const select = document.getElementById("membership-select");
                const membershipId = select?.value || null;
                try {
                    await apiPost("/api/app/bookings", {
                        eventInstanceId: data.event.id,
                        membershipId: membershipId || null
                    });
                    window.location.hash = "#/me?notice=booked";
                } catch (error) {
                    actor.send({ type: "REFRESH" });
                    alert(error.message);
                }
            });
        }

        document.querySelectorAll("button[data-plan]").forEach(btn => {
            btn.addEventListener("click", async () => {
                const planId = btn.getAttribute("data-plan");
                if (!planId) return;
                try {
                    await apiPost("/api/app/checkout", { planId, couponCode: null });
                    actor.send({ type: "REFRESH" });
                } catch (error) {
                    alert(error.message);
                }
            });
        });
    }

    if (route === "me")
    {
        document.querySelectorAll("button[data-cancel]").forEach(btn => {
            btn.addEventListener("click", async () => {
                const id = btn.getAttribute("data-cancel");
                if (!window.confirm("Cancel this booking?")) return;
                await apiPost(`/api/app/bookings/${id}/cancel`, {});
                window.location.hash = "#/me?notice=cancelled";
            });
        });
    }

    if (route === "profile")
    {
        const profileForm = document.getElementById("profile-form");
        const healthForm = document.getElementById("health-form");
        if (profileForm) {
            profileForm.addEventListener("submit", async (event) => {
                event.preventDefault();
                const formData = new FormData(profileForm);
                await apiPut("/api/app/me/profile", {
                    fullName: formData.get("fullName"),
                    phone: formData.get("phone")
                });
                actor.send({ type: "REFRESH" });
            });
        }
        if (healthForm) {
            healthForm.addEventListener("submit", async (event) => {
                event.preventDefault();
                const formData = new FormData(healthForm);
                await apiPost("/api/app/me/health-declaration", {
                    payloadJson: formData.get("payloadJson"),
                    signatureName: formData.get("signatureName"),
                    signatureType: "typed"
                });
                actor.send({ type: "REFRESH" });
            });
        }
    }
}

function normalizeStatus(value) {
    if (typeof value === "string") {
        return value;
    }
    return value === 1 ? "Cancelled" : "Scheduled";
}

function buildMembershipLabel(membership) {
    const plan = membership.plan || {};
    const type = plan.type || "";
    if (type === "Unlimited" || type === 2) {
        return `${plan.name} (Unlimited)`;
    }
    if (type === "PunchCard" || type === 1) {
        return `${plan.name} (${membership.remainingUses || 0} left)`;
    }
    if (type === "WeeklyLimit" || type === 0) {
        return `${plan.name} (Weekly limit)`;
    }
    return plan.name || "Membership";
}

function groupScheduleItems(items) {
    const map = new Map();
    items.forEach(item => {
        if (!map.has(item.dateKey)) {
            map.set(item.dateKey, { label: item.dateLabel, items: [] });
        }
        map.get(item.dateKey).items.push(item);
    });
    return Array.from(map.entries())
        .sort((a, b) => a[0].localeCompare(b[0]))
        .map(entry => entry[1]);
}

function toDateKeyLocal(value) {
    const date = new Date(value);
    const year = date.getFullYear();
    const month = String(date.getMonth() + 1).padStart(2, "0");
    const day = String(date.getDate()).padStart(2, "0");
    return `${year}-${month}-${day}`;
}

function formatDateLabel(value) {
    const date = new Date(value);
    return new Intl.DateTimeFormat("en-US", {
        weekday: "long",
        month: "short",
        day: "numeric"
    }).format(date);
}

actor.subscribe((state) => {
    render(state);
});

actor.start();

const appRoutes = new Set(["schedule", "event", "me", "payments", "profile"]);

function parseHash(defaultRoute) {
    const hash = window.location.hash || `#/${defaultRoute}`;
    const cleaned = hash.replace(/^#\/?/, "");
    const [path] = cleaned.split("?");
    const parts = path.split("/").filter(Boolean);
    const route = parts[0] || defaultRoute;
    const params = {};
    if (route === "event" && parts[1]) {
        params.id = parts[1];
    }
    return { route, params };
}

function handleRouteChange() {
    const { route, params } = parseHash("schedule");
    const nextRoute = appRoutes.has(route) ? route : "schedule";
    actor.send({ type: "NAVIGATE", route: nextRoute, params });
}

window.addEventListener("hashchange", handleRouteChange);
handleRouteChange();






