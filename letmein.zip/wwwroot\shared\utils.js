﻿export function formatDateTime(iso, timeZone) {
    if (!iso) return "";
    const date = new Date(iso);
    return new Intl.DateTimeFormat("en-US", {
        timeZone: timeZone || "UTC",
        weekday: "short",
        month: "short",
        day: "numeric",
        hour: "numeric",
        minute: "2-digit"
    }).format(date);
}

export function formatMoney(cents, currency) {
    const amount = (cents || 0) / 100;
    return new Intl.NumberFormat("en-US", {
        style: "currency",
        currency: currency || "USD",
        maximumFractionDigits: 0
    }).format(amount);
}

export function toDateInputValue(date) {
    const value = date || new Date();
    return value.toISOString().slice(0, 10);
}

export function getStudioSlugFromPath() {
    const parts = window.location.pathname.split("/").filter(Boolean);
    const sIndex = parts.indexOf("s");
    if (sIndex >= 0 && parts.length > sIndex + 1) {
        return parts[sIndex + 1];
    }
    return "";
}

export function getQueryParam(name) {
    const params = new URLSearchParams(window.location.search);
    if (params.has(name)) {
        return params.get(name);
    }

    const hash = window.location.hash || "";
    if (hash.includes("?")) {
        const query = hash.split("?")[1];
        const hashParams = new URLSearchParams(query);
        return hashParams.get(name);
    }

    return null;
}

export function setQueryParam(name, value) {
    const url = new URL(window.location.href);
    if (value) {
        url.searchParams.set(name, value);
    } else {
        url.searchParams.delete(name);
    }
    window.history.replaceState({}, "", url.toString());
}

