﻿import { createMachine, createActor, fromPromise, assign } from "xstate";
import { apiGet, apiPost, apiPut, apiDelete } from "../shared/api.js";
import { login, logout, getSession, loadSessionHint } from "../shared/auth.js";
import { compileTemplate } from "../shared/templates.js";
import { formatMoney, getQueryParam, toDateInputValue } from "../shared/utils.js";

const root = document.getElementById("app");
const sessionHint = loadSessionHint();

const layoutTemplate = compileTemplate("layout", `
  <div class="app-shell">
    <aside class="sidebar">
      <div class="brand">
        <div class="brand-badge"></div>
        Letmein Admin
      </div>
      <nav class="nav">
        <a href="#/calendar" data-route="calendar">Calendar</a>
        <a href="#/events" data-route="events">Event Series</a>
        <a href="#/plans" data-route="plans">Plans</a>
        <a href="#/customers" data-route="customers">Customers</a>
        <a href="#/reports" data-route="reports">Reports</a>
        <a href="#/settings" data-route="settings">Settings</a>
      </nav>
      <footer>
        <div class="tag">Demo mode enabled</div>
      </footer>
    </aside>
    <main class="main">
      <div class="topbar">
        <div>
          <h1>{{title}}</h1>
          <div class="muted">{{subtitle}}</div>
        </div>
        <button class="secondary" id="logout-btn">Log out</button>
      </div>
      <div class="surface">
        {{{content}}}
      </div>
    </main>
  </div>
`);

const loginTemplate = compileTemplate("login", `
  <div class="login-shell">
    <div class="login-card">
      <h1>Welcome back</h1>
      <p>Run ops for your studio in one place.</p>
      {{#if error}}
        <div class="notice">{{error}}</div>
      {{/if}}
      <form id="login-form">
        <label>Email</label>
        <input type="email" name="email" required value="admin@letmein.local" />
        <label>Password</label>
        <input type="password" name="password" required value="admin123" />
        <label>Studio slug</label>
        <input type="text" name="studioSlug" required value="{{studioSlug}}" />
        <label>Role</label>
        <select name="role">
          <option value="admin">Admin</option>
          <option value="staff">Staff</option>
          <option value="instructor">Instructor</option>
        </select>
        <div style="margin-top:16px;">
          <button type="submit">Log in</button>
        </div>
      </form>
    </div>
  </div>
`);

const calendarTemplate = compileTemplate("calendar", `
  <div class="calendar-toolbar">
    <div class="calendar-views">
      <button class="secondary {{#if isDay}}active{{/if}}" data-view="day">Day</button>
      <button class="secondary {{#if isWeek}}active{{/if}}" data-view="week">Week</button>
      <button class="secondary {{#if isMonth}}active{{/if}}" data-view="month">Month</button>
    </div>
    <div class="calendar-nav">
      <button class="secondary" data-nav="prev">Prev</button>
      <input type="date" id="calendar-date" value="{{focusDate}}" />
      <button class="secondary" data-nav="next">Next</button>
    </div>
    <div class="calendar-actions">
      <button id="add-session">Add session</button>
    </div>
    <div class="calendar-range">{{rangeLabel}}</div>
  </div>
  <div class="calendar-body">
    {{#if isDay}}
      <div class="calendar-day">
        <div class="calendar-day-header">{{day.label}}</div>
        {{#if day.hasEvents}}
          <div class="calendar-events">
            {{#each day.events}}
              <div class="calendar-event {{#if isCancelled}}cancelled{{/if}}" data-event="{{id}}">
                <div class="event-time">{{timeRange}}</div>
                <div class="event-title">{{seriesTitle}}</div>
                <div class="event-meta">{{roomName}} - {{instructorName}}</div>
                <div class="event-meta">{{booked}} / {{capacity}} - {{price}}</div>
                {{#if isCancelled}}
                  <div class="event-meta">Cancelled</div>
                {{/if}}
              </div>
            {{/each}}
          </div>
        {{else}}
          <div class="empty-state">No classes scheduled.</div>
        {{/if}}
      </div>
    {{/if}}
    {{#if isWeek}}
      <div class="calendar-week">
        {{#each week.days}}
          <div class="calendar-day-column {{#if isToday}}today{{/if}}">
            <div class="calendar-day-label">
              <span>{{weekday}}</span>
              <span class="date">{{dateLabel}}</span>
            </div>
            {{#if hasEvents}}
              <div class="calendar-day-events">
                {{#each events}}
                  <div class="calendar-event compact {{#if isCancelled}}cancelled{{/if}}" data-event="{{id}}">
                    <div class="event-time">{{timeRange}}</div>
                    <div class="event-title">{{seriesTitle}}</div>
                    <div class="event-meta">{{roomName}}</div>
                    <div class="event-meta">{{instructorName}}</div>
                  </div>
                {{/each}}
              </div>
            {{else}}
              <div class="empty-slot">No classes</div>
            {{/if}}
          </div>
        {{/each}}
      </div>
    {{/if}}
    {{#if isMonth}}
      <div class="calendar-month">
        <div class="calendar-weekdays">
          {{#each month.weekdays}}
            <div>{{this}}</div>
          {{/each}}
        </div>
        <div class="calendar-month-grid">
          {{#each month.weeks}}
            {{#each days}}
              <div class="calendar-month-day {{#unless isCurrentMonth}}muted{{/unless}} {{#if isToday}}today{{/if}}">
                <div class="date-number">{{label}}</div>
                {{#if hasEvents}}
                  <div class="calendar-month-events">
                    {{#each eventsPreview}}
                      <div class="calendar-event mini {{#if isCancelled}}cancelled{{/if}}" data-event="{{id}}">
                        <span class="event-time">{{time}}</span>
                        <span class="event-title">{{title}}</span>
                      </div>
                    {{/each}}
                    {{#if moreCount}}
                      <div class="more-events">+{{moreCount}} more</div>
                    {{/if}}
                  </div>
                {{/if}}
              </div>
            {{/each}}
          {{/each}}
        </div>
      </div>
    {{/if}}
  </div>
`);

const calendarModalTemplate = compileTemplate("calendar-modal", `
  <div class="modal-overlay" id="calendar-modal">
    <div class="modal">
      <div class="modal-header">
        <div>
          <h3>{{seriesTitle}}</h3>
          <div class="muted">{{startLabel}} ({{timeRange}})</div>
          <div class="meta">{{roomName}} - {{instructorName}}</div>
        </div>
        <button class="secondary" id="close-modal">Close</button>
      </div>
      <div class="form-grid">
        <div>
          <label>Status</label>
          <select name="status">
            {{#each statuses}}
              <option value="{{value}}" {{#if selected}}selected{{/if}}>{{label}}</option>
            {{/each}}
          </select>
        </div>
        <div>
          <label>Room</label>
          <select name="roomId">
            {{#each rooms}}
              <option value="{{id}}" {{#if selected}}selected{{/if}}>{{name}}</option>
            {{/each}}
          </select>
        </div>
        <div>
          <label>Instructor</label>
          <select name="instructorId">
            {{#each instructors}}
              <option value="{{id}}" {{#if selected}}selected{{/if}}>{{displayName}}</option>
            {{/each}}
          </select>
        </div>
        <div>
          <label>Capacity</label>
          <input type="number" name="capacity" value="{{capacity}}" />
        </div>
        <div>
          <label>Price (cents)</label>
          <input type="number" name="priceCents" value="{{priceCents}}" />
        </div>
      </div>
      <div class="roster">
        <h4>Registrations</h4>
        <div class="roster-actions">
          <label class="checkbox">
            <input type="checkbox" id="roster-select-all" />
            Select all
          </label>
          <div class="roster-actions-buttons">
            <button class="secondary" id="roster-email">Email selected</button>
            <button class="secondary" id="roster-sms">SMS selected</button>
          </div>
        </div>
        {{#if roster.length}}
          <table class="table roster-table">
            <thead>
              <tr>
                <th></th>
                <th>Customer</th>
                <th>Email</th>
                <th>Booking</th>
                <th>Attendance</th>
              </tr>
            </thead>
            <tbody>
              {{#each roster}}
              <tr>
                <td>
                  <input type="checkbox" data-roster-select="{{customerId}}" />
                </td>
                <td>{{customerName}}</td>
                <td>{{email}}</td>
                <td>{{bookingStatusLabel}}</td>
                <td>
                  {{#if isCancelled}}
                    <span class="muted">Cancelled</span>
                  {{else}}
                    <select data-attendance="{{customerId}}">
                      <option value="Registered" {{#if isRegistered}}selected{{/if}}>Registered</option>
                      <option value="Present" {{#if isPresent}}selected{{/if}}>Present</option>
                      <option value="NoShow" {{#if isNoShow}}selected{{/if}}>No-show</option>
                    </select>
                  {{/if}}
                </td>
              </tr>
              {{/each}}
            </tbody>
          </table>
        {{else}}
          <div class="empty-state">No registrations yet.</div>
        {{/if}}
      </div>
      <div class="registration-form">
        <h4>Manual registration</h4>
        <div class="form-grid">
          <div>
            <label>Existing customer</label>
            <select name="customerId">
              <option value="">Select customer</option>
              {{#each customers}}
                <option value="{{id}}">{{fullName}} ({{email}})</option>
              {{/each}}
            </select>
          </div>
          <div>
            <label>Multiple customers</label>
            <select name="customerIds" multiple size="4">
              {{#each customers}}
                <option value="{{id}}">{{fullName}} ({{email}})</option>
              {{/each}}
            </select>
          </div>
          <div>
            <label>Full name</label>
            <input name="fullName" placeholder="New customer name" />
          </div>
          <div>
            <label>Email</label>
            <input name="email" type="email" placeholder="name@email.com" />
          </div>
          <div>
            <label>Phone</label>
            <input name="phone" type="tel" placeholder="+1 555 123 4567" />
          </div>
        </div>
        <div class="modal-footer">
          <div class="meta">Add a new or existing customer to this class.</div>
          <div class="modal-actions">
            <button id="register-customer">Register customer</button>
          </div>
        </div>
      </div>
      <div class="modal-footer">
        <div class="meta">Booked: {{booked}} / {{capacity}}</div>
        <div class="modal-actions">
          <button id="save-instance">Save changes</button>
          <button class="secondary" id="edit-series">Edit series</button>
        </div>
      </div>
    </div>
  </div>
`);

const sessionModalTemplate = compileTemplate("session-modal", `
  <div class="modal-overlay" id="session-modal">
    <div class="modal">
      <div class="modal-header">
        <div>
          <h3>Add session</h3>
          <div class="muted">Create a one-time class or a recurring series.</div>
        </div>
        <button class="secondary" id="close-session">Close</button>
      </div>
      <div class="form-grid">
        <div>
          <label>Type</label>
          <select name="sessionType">
            <option value="one-time">One-time</option>
            <option value="recurring">Recurring</option>
          </select>
        </div>
        <div>
          <label>Title</label>
          <input name="title" value="Studio Flow" />
        </div>
        <div>
          <label>Description</label>
          <input name="description" value="" />
        </div>
        <div>
          <label>Instructor</label>
          <select name="instructorId">
            <option value="">Unassigned</option>
            {{#each instructors}}
              <option value="{{id}}">{{displayName}}</option>
            {{/each}}
          </select>
        </div>
        <div>
          <label>Room</label>
          <select name="roomId">
            <option value="">Unassigned</option>
            {{#each rooms}}
              <option value="{{id}}">{{name}}</option>
            {{/each}}
          </select>
        </div>
        <div>
          <label>Start time</label>
          <input type="time" name="startTimeLocal" value="18:00" />
        </div>
        <div>
          <label>Duration (min)</label>
          <input type="number" name="durationMinutes" value="60" />
        </div>
        <div>
          <label>Capacity</label>
          <input type="number" name="capacity" value="14" />
        </div>
        <div>
          <label>Price (cents)</label>
          <input type="number" name="priceCents" value="2500" />
        </div>
        <div>
          <label>Currency</label>
          <input name="currency" value="USD" />
        </div>
        <div>
          <label>Cancellation window (hours)</label>
          <input type="number" name="cancellationWindowHours" value="6" />
        </div>
      </div>
      <div class="form-grid session-one-time">
        <div>
          <label>Date</label>
          <input type="date" name="date" value="{{focusDate}}" />
        </div>
      </div>
      <div class="form-grid session-recurring hidden">
        <div>
          <label>Start date</label>
          <input type="date" name="startDate" value="{{focusDate}}" />
        </div>
        <div>
          <label>Day of week</label>
          <select name="dayOfWeek">
            <option value="1">Monday</option>
            <option value="2">Tuesday</option>
            <option value="3">Wednesday</option>
            <option value="4">Thursday</option>
            <option value="5">Friday</option>
            <option value="6">Saturday</option>
            <option value="0">Sunday</option>
          </select>
        </div>
        <div>
          <label>Recurrence (weeks)</label>
          <input type="number" name="recurrenceIntervalWeeks" value="1" />
        </div>
        <div>
          <label>Generate weeks</label>
          <input type="number" name="generateWeeks" value="8" />
        </div>
      </div>
      <div class="modal-footer">
        <div class="meta">Sessions appear on the calendar immediately.</div>
        <div class="modal-actions">
          <button id="save-session">Create session</button>
        </div>
      </div>
    </div>
  </div>
`);

const bulkRegistrationTemplate = compileTemplate("bulk-registration", `
  <div class="modal-overlay" id="bulk-registration-modal">
    <div class="modal">
      <div class="modal-header">
        <div>
          <h3>Register selected customers</h3>
          <div class="muted">{{count}} customers selected</div>
        </div>
        <button class="secondary" id="close-bulk-registration">Close</button>
      </div>
      <div class="form-grid">
        <div>
          <label>Session</label>
          <select name="sessionId">
            {{#each sessions}}
              <option value="{{id}}">{{label}}</option>
            {{/each}}
          </select>
        </div>
      </div>
      <div class="modal-footer">
        <div class="meta">Registers all selected customers to the chosen session.</div>
        <div class="modal-actions">
          <button id="confirm-bulk-registration">Register</button>
        </div>
      </div>
    </div>
  </div>
`);

const eventsTemplate = compileTemplate("events", `
  <div class="notice">Create weekly series and auto-generate classes.</div>
  <input type="hidden" name="seriesId" value="{{activeSeriesId}}" />
  <div class="form-grid">
    <div>
      <label>Title</label>
      <input name="title" value="{{title}}" />
    </div>
    <div>
      <label>Day of week</label>
      <select name="dayOfWeek">
        <option value="1">Monday</option>
        <option value="2">Tuesday</option>
        <option value="3">Wednesday</option>
        <option value="4">Thursday</option>
        <option value="5">Friday</option>
        <option value="6">Saturday</option>
        <option value="0">Sunday</option>
      </select>
    </div>
    <div>
      <label>Start time</label>
      <input type="time" name="startTimeLocal" value="{{startTimeLocal}}" />
    </div>
    <div>
      <label>Duration (min)</label>
      <input type="number" name="durationMinutes" value="{{durationMinutes}}" />
    </div>
    <div>
      <label>Capacity</label>
      <input type="number" name="capacity" value="{{defaultCapacity}}" />
    </div>
    <div>
      <label>Price (cents)</label>
      <input type="number" name="priceCents" value="{{priceCents}}" />
    </div>
    <div>
      <label>Instructor</label>
      <select name="instructorId">
        {{#each instructors}}
          <option value="{{id}}">{{displayName}}</option>
        {{/each}}
      </select>
    </div>
    <div>
      <label>Room</label>
      <select name="roomId">
        {{#each rooms}}
          <option value="{{id}}">{{name}}</option>
        {{/each}}
      </select>
    </div>
    <div>
      <label>Description</label>
      <textarea name="description" rows="2">{{description}}</textarea>
    </div>
    <div>
      <label>Recurrence (weeks)</label>
      <input type="number" name="recurrenceIntervalWeeks" value="{{recurrenceIntervalWeeks}}" />
    </div>
    <div>
      <label>Cancellation window (hours)</label>
      <input type="number" name="cancellationWindowHours" value="{{cancellationWindowHours}}" />
    </div>
    <div>
      <label>Active</label>
      <select name="isActive">
        <option value="true" {{#if isActive}}selected{{/if}}>Yes</option>
        <option value="false" {{#unless isActive}}selected{{/unless}}>No</option>
      </select>
    </div>
  </div>
  <div style="margin-top:16px;">
    <button id="save-series">{{saveLabel}}</button>
    <button class="secondary" id="clear-series">Clear</button>
  </div>
  <div style="margin-top:24px;">
    <table class="table">
      <thead>
        <tr>
          <th>Title</th>
          <th>Day</th>
          <th>Time</th>
          <th>Capacity</th>
          <th>Active</th>
          <th>Actions</th>
        </tr>
      </thead>
      <tbody>
        {{#each series}}
        <tr>
          <td>{{title}}</td>
          <td>{{dayLabel}}</td>
          <td>{{startTimeLocal}}</td>
          <td>{{defaultCapacity}}</td>
          <td>{{isActive}}</td>
          <td>
            <button class="secondary" data-edit="{{id}}">Edit</button>
            <button data-generate="{{id}}">Generate</button>
          </td>
        </tr>
        {{/each}}
      </tbody>
    </table>
  </div>
`);

const plansTemplate = compileTemplate("plans", `
  <div class="form-grid">
    <div>
      <label>Name</label>
      <input name="name" value="2x Weekly Pass" />
    </div>
    <div>
      <label>Type</label>
      <select name="type">
        <option value="WeeklyLimit">Weekly limit</option>
        <option value="PunchCard">Punch card</option>
        <option value="Unlimited">Unlimited</option>
      </select>
    </div>
    <div>
      <label>Weekly limit</label>
      <input type="number" name="weeklyLimit" value="2" />
    </div>
    <div>
      <label>Punch card uses</label>
      <input type="number" name="punchCardUses" value="0" />
    </div>
    <div>
      <label>Price (cents)</label>
      <input type="number" name="priceCents" value="12000" />
    </div>
    <div>
      <label>Currency</label>
      <input name="currency" value="USD" />
    </div>
  </div>
  <div style="margin-top:16px;">
    <button id="create-plan">Create plan</button>
  </div>
  <div style="margin-top:24px;">
    <table class="table">
      <thead>
        <tr>
          <th>Name</th>
          <th>Type</th>
          <th>Price</th>
          <th>Active</th>
        </tr>
      </thead>
      <tbody>
        {{#each plans}}
        <tr>
          <td>{{name}}</td>
          <td>{{type}}</td>
          <td>{{price}}</td>
          <td>{{active}}</td>
        </tr>
        {{/each}}
      </tbody>
    </table>
  </div>
`);

const customersTemplate = compileTemplate("customers", `
  <div class="notice">Manage customer profiles, contacts, and status.</div>
  <input type="hidden" name="customerId" value="{{activeCustomerId}}" />
  <div class="form-grid">
    <div>
      <label>Full name</label>
      <input name="fullName" value="{{fullName}}" />
    </div>
    <div>
      <label>Email</label>
      <input name="email" type="email" value="{{email}}" />
    </div>
    <div>
      <label>Phone</label>
      <input name="phone" type="tel" value="{{phone}}" />
    </div>
    <div>
      <label>Tags (JSON)</label>
      <input name="tagsJson" value="{{tagsJson}}" />
    </div>
    <div>
      <label>Archived</label>
      <select name="isArchived">
        <option value="false" {{#unless isArchived}}selected{{/unless}}>No</option>
        <option value="true" {{#if isArchived}}selected{{/if}}>Yes</option>
      </select>
    </div>
    <div>
      <label>Password (optional)</label>
      <input name="password" type="password" placeholder="Leave empty for temp password" />
    </div>
  </div>
  <div class="toolbar">
    <button id="save-customer">{{saveLabel}}</button>
    <button class="secondary" id="clear-customer">Clear</button>
  </div>
  <div class="customer-controls">
    <input type="search" name="search" placeholder="Search customers" value="{{search}}" />
    <label class="checkbox">
      <input type="checkbox" name="includeArchived" {{#if includeArchived}}checked{{/if}} />
      Show archived
    </label>
    <label class="checkbox">
      <input type="checkbox" id="customers-select-all" />
      Select all
    </label>
    <button class="secondary" id="apply-customer-filters">Apply</button>
    <div class="bulk-actions">
      <button class="secondary" id="bulk-email">Email selected</button>
      <button class="secondary" id="bulk-sms">SMS selected</button>
      <button class="secondary" id="bulk-register">Register to class</button>
    </div>
  </div>
  <table class="table">
    <thead>
      <tr>
        <th></th>
        <th>Name</th>
        <th>Email</th>
        <th>Phone</th>
        <th>Status</th>
        <th>Actions</th>
      </tr>
    </thead>
    <tbody>
      {{#each customers}}
      <tr class="{{#if isArchived}}row-muted{{/if}}">
        <td><input type="checkbox" data-customer-select="{{id}}" /></td>
        <td>{{fullName}}</td>
        <td><a href="mailto:{{email}}">{{email}}</a></td>
        <td>
          <a href="tel:{{phone}}">{{phone}}</a>
          <a href="sms:{{phone}}" class="link-muted">SMS</a>
        </td>
        <td>{{statusLabel}}</td>
        <td>
          <button class="secondary" data-edit="{{id}}">Edit</button>
          <button class="secondary" data-archive="{{id}}">{{archiveLabel}}</button>
        </td>
      </tr>
      {{/each}}
    </tbody>
  </table>
`);

const reportsTemplate = compileTemplate("reports", `
  <div class="cards">
    <div class="card">
      <div class="card-title">Revenue (30d)</div>
      <div class="card-value">{{revenue}}</div>
    </div>
    <div class="card">
      <div class="card-title">Total sessions</div>
      <div class="card-value">{{sessions}}</div>
    </div>
    <div class="card">
      <div class="card-title">Avg occupancy</div>
      <div class="card-value">{{occupancy}}%</div>
    </div>
  </div>
`);

const settingsTemplate = compileTemplate("settings", `
  <div class="form-grid">
    <div>
      <label>Studio name</label>
      <input name="name" value="{{name}}" />
    </div>
    <div>
      <label>Timezone</label>
      <input name="timezone" value="{{timezone}}" />
    </div>
    <div>
      <label>Week starts on</label>
      <input name="weekStartsOn" type="number" value="{{weekStartsOn}}" />
    </div>
    <div>
      <label>Theme JSON</label>
      <textarea name="themeJson" rows="3">{{themeJson}}</textarea>
    </div>
  </div>
  <div style="margin-top:16px;">
    <button id="save-settings">Save settings</button>
  </div>
`);

const adminMachine = createMachine({
    id: "admin",
    initial: "boot",
    context: {
        user: null,
        studio: null,
        route: "calendar",
        calendarView: "week",
        calendarDate: toDateInputValue(new Date()),
        data: {},
        error: ""
    },
    states: {
        boot: {
            invoke: {
                src: "loadSession",
                onDone: {
                    target: "loading",
                    actions: "setSession"
                },
                onError: {
                    target: "login"
                }
            }
        },
        login: {
            on: {
                LOGIN_SUCCESS: {
                    target: "loading",
                    actions: "setSession"
                }
            }
        },
        loading: {
            invoke: {
                src: "loadRoute",
                input: ({ context }) => context,
                onDone: {
                    target: "ready",
                    actions: "setData"
                },
                onError: {
                    target: "ready",
                    actions: "setError"
                }
            }
        },
        ready: {
            on: {
                NAVIGATE: {
                    target: "loading",
                    actions: "setRoute"
                },
                SET_CALENDAR: {
                    target: "loading",
                    actions: "setCalendar"
                },
                REFRESH: {
                    target: "loading"
                }
            }
        }
    }
}, {
    actions: {
        setSession: assign(({ context, event }) => {
            const payload = event.output ?? event;
            return {
                ...context,
                user: payload.user ?? context.user,
                studio: payload.studio ?? context.studio,
                error: ""
            };
        }),
        setRoute: assign(({ context, event }) => ({
            ...context,
            route: event.route
        })),
        setCalendar: assign(({ context, event }) => ({
            ...context,
            calendarView: event.view ?? context.calendarView,
            calendarDate: event.date ?? context.calendarDate
        })),
        setData: assign(({ context, event }) => ({
            ...context,
            data: event.output,
            error: ""
        })),
        setError: assign(({ context, event }) => ({
            ...context,
            error: event.error?.message || "Unable to load data"
        }))
    },
    actors: {
        loadSession: fromPromise(async () => {
            const session = await getSession();
            return { user: session.user, studio: session.studio };
        }),
        loadRoute: fromPromise(async ({ input }) => {
            switch (input.route) {
                case "calendar": {
                    const studio = await apiGet("/api/admin/studio");
                    const view = input.calendarView || "week";
                    const focusDate = input.calendarDate || toDateInputValue(new Date());
                    const range = getCalendarRange(view, focusDate, studio.weekStartsOn ?? 0);
                    const [items, rooms, instructors, customers] = await Promise.all([
                        apiGet(`/api/admin/calendar?from=${range.from}&to=${range.to}`),
                        apiGet("/api/admin/rooms"),
                        apiGet("/api/admin/instructors"),
                        apiGet("/api/admin/customers")
                    ]);
                    return { items, rooms, instructors, customers, calendar: { view, focusDate, studio, range } };
                }
                case "events": {
                    const series = await apiGet("/api/admin/event-series");
                    const rooms = await apiGet("/api/admin/rooms");
                    const instructors = await apiGet("/api/admin/instructors");
                    return { series, rooms, instructors };
                }
                case "plans": {
                    const plans = await apiGet("/api/admin/plans");
                    return { plans };
                }
                case "customers": {
                    const search = getQueryParam("search") || "";
                    const includeArchived = getQueryParam("archived") === "1";
                    const query = new URLSearchParams();
                    if (search) query.set("search", search);
                    if (includeArchived) query.set("includeArchived", "true");
                    const qs = query.toString();
                    const customers = await apiGet(`/api/admin/customers${qs ? `?${qs}` : ""}`);
                    return { customers, customerFilters: { search, includeArchived } };
                }
                case "reports": {
                    const revenue = await apiGet("/api/admin/reports/revenue");
                    const occupancy = await apiGet("/api/admin/reports/occupancy");
                    return { revenue, occupancy };
                }
                case "settings": {
                    const studio = await apiGet("/api/admin/studio");
                    return { studio };
                }
                default:
                    return {};
            }
        })
    }
});

const actor = createActor(adminMachine);

function render(state) {
    if (state.matches("login")) {
        root.innerHTML = loginTemplate({ error: state.context.error, studioSlug: sessionHint.studioSlug || "demo" });
        bindLogin();
        return;
    }

    const route = state.context.route;
    const titleMap = {
        calendar: "Calendar",
        events: "Event series",
        plans: "Membership plans",
        customers: "Customer roster",
        reports: "Performance pulse",
        settings: "Studio settings"
    };

    const subtitleMap = {
        calendar: "Week view of live classes.",
        events: "Templates that drive recurring schedules.",
        plans: "Sell weekly limits or unlimited passes.",
        customers: "Top-level view of active clients.",
        reports: "Revenue and occupancy at a glance.",
        settings: "Brand, timezone, and week logic."
    };

    let content = "";
    const data = state.context.data || {};
    let subtitle = subtitleMap[route] || "";

    if (route === "calendar") {
        const calendarMeta = data.calendar || {};
        const view = calendarMeta.view || state.context.calendarView || "week";
        const focusDate = calendarMeta.focusDate || state.context.calendarDate || toDateInputValue(new Date());
        const studio = calendarMeta.studio || {};
        const timeZone = studio.timezone || "UTC";
        const weekStartsOn = studio.weekStartsOn ?? 0;
        const viewState = buildCalendarView(data.items || [], {
            view,
            focusDate,
            timeZone,
            weekStartsOn
        });
        const subtitleMapView = {
            day: "Daily schedule focus.",
            week: "Weekly schedule overview.",
            month: "Month at a glance."
        };
        subtitle = subtitleMapView[view] || subtitle;
        content = calendarTemplate(viewState);
    }

    if (route === "events") {
        const dayNames = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];
        const series = (data.series || []).map(item => ({
            ...item,
            dayLabel: dayNames[item.dayOfWeek] || "",
            startTimeLocal: item.startTimeLocal,
            isActive: item.isActive ? "Yes" : "No"
        }));
        const form = data.form || {
            title: "Studio Flow",
            dayOfWeek: 2,
            startTimeLocal: "18:00",
            durationMinutes: 60,
            defaultCapacity: 14,
            priceCents: 2500,
            description: "",
            recurrenceIntervalWeeks: 1,
            cancellationWindowHours: 6,
            isActive: true,
            activeSeriesId: ""
        };
        content = eventsTemplate({
            ...form,
            saveLabel: form.activeSeriesId ? "Update series" : "Create series",
            series,
            rooms: data.rooms || [],
            instructors: data.instructors || []
        });
    }

    if (route === "plans") {
        const plans = (data.plans || []).map(plan => ({
            ...plan,
            price: formatMoney(plan.priceCents, plan.currency),
            active: plan.active ? "Yes" : "No"
        }));
        content = plansTemplate({ plans });
    }

    if (route === "customers") {
        const customers = (data.customers || []).map(c => ({
            ...c,
            statusLabel: c.isArchived ? "Archived" : "Active",
            archiveLabel: c.isArchived ? "Restore" : "Archive"
        }));
        const filters = data.customerFilters || { search: "", includeArchived: false };
        const form = data.form || {
            fullName: "",
            email: "",
            phone: "",
            tagsJson: "[]",
            isArchived: false,
            activeCustomerId: ""
        };
        content = customersTemplate({
            ...form,
            saveLabel: form.activeCustomerId ? "Update customer" : "Create customer",
            customers,
            search: filters.search || "",
            includeArchived: filters.includeArchived
        });
    }

    if (route === "reports") {
        const revenue = formatMoney(data.revenue?.totalCents || 0, "USD");
        const totalSessions = (data.occupancy || []).reduce((sum, item) => sum + item.sessions, 0);
        const totalCapacity = (data.occupancy || []).reduce((sum, item) => sum + item.capacity, 0);
        const totalBooked = (data.occupancy || []).reduce((sum, item) => sum + item.booked, 0);
        const occupancyRate = totalCapacity ? Math.round((totalBooked / totalCapacity) * 100) : 0;
        content = reportsTemplate({ revenue, sessions: totalSessions, occupancy: occupancyRate });
    }

    if (route === "settings") {
        const studio = data.studio || {};
        content = settingsTemplate({
            name: studio.name || "",
            timezone: studio.timezone || "UTC",
            weekStartsOn: studio.weekStartsOn || 0,
            themeJson: studio.themeJson || "{}"
        });
    }

    root.innerHTML = layoutTemplate({
        title: titleMap[route] || "Admin",
        subtitle,
        content
    });

    document.querySelectorAll(".nav a").forEach(link => {
        const routeName = link.getAttribute("data-route");
        if (routeName === route) {
            link.classList.add("active");
        }
    });

    const logoutBtn = document.getElementById("logout-btn");
    if (logoutBtn) {
        logoutBtn.addEventListener("click", async () => {
            await logout();
            actor.send({ type: "LOGIN_REQUIRED" });
            window.location.reload();
        });
    }

    bindRouteActions(route, data, state);
}

function bindLogin() {
    const form = document.getElementById("login-form");
    if (!form) return;
    form.addEventListener("submit", async (event) => {
        event.preventDefault();
        const formData = new FormData(form);
        const payload = {
            email: formData.get("email"),
            password: formData.get("password"),
            role: formData.get("role"),
            studioSlug: formData.get("studioSlug")
        };
        try {
            const result = await login(payload);
            actor.send({ type: "LOGIN_SUCCESS", output: result });
        } catch (error) {
            actor.send({ type: "LOGIN_FAILURE", error });
            root.innerHTML = loginTemplate({ error: error.message, studioSlug: payload.studioSlug });
            bindLogin();
        }
    });
}

function bindRouteActions(route, data, state) {
    if (route === "calendar") {
        const calendarMeta = data.calendar || {};
        const currentView = calendarMeta.view || state.context.calendarView || "week";
        const currentDate = calendarMeta.focusDate || state.context.calendarDate || toDateInputValue(new Date());
        const viewButtons = document.querySelectorAll("button[data-view]");
        const navButtons = document.querySelectorAll("button[data-nav]");
        const dateInput = document.getElementById("calendar-date");

        viewButtons.forEach(btn => {
            btn.addEventListener("click", () => {
                const view = btn.getAttribute("data-view") || "week";
                const selectedDate = dateInput?.value || currentDate;
                actor.send({ type: "SET_CALENDAR", view, date: selectedDate });
            });
        });

        navButtons.forEach(btn => {
            btn.addEventListener("click", () => {
                const direction = btn.getAttribute("data-nav") === "prev" ? -1 : 1;
                const baseDate = dateInput?.value || currentDate;
                const nextDate = shiftCalendarDate(currentView, baseDate, direction);
                actor.send({ type: "SET_CALENDAR", view: currentView, date: nextDate });
            });
        });

        if (dateInput) {
            dateInput.addEventListener("change", () => {
                const nextDate = dateInput.value || currentDate;
                actor.send({ type: "SET_CALENDAR", view: currentView, date: nextDate });
            });
        }

        const addSessionBtn = document.getElementById("add-session");
        if (addSessionBtn) {
            addSessionBtn.addEventListener("click", () => {
                openSessionModal(data);
            });
        }

        const itemMap = new Map((data.items || []).map(item => [String(item.id), item]));
        document.querySelectorAll(".calendar-event[data-event]").forEach(card => {
            card.addEventListener("click", () => {
                const id = card.getAttribute("data-event");
                const item = itemMap.get(String(id));
                if (!item) return;
                openCalendarEventModal(item, data);
            });
        });
    }

    if (route === "events") {
        const button = document.getElementById("save-series");
        const clearButton = document.getElementById("clear-series");
        const seriesIdParam = getQueryParam("series");
        if (seriesIdParam && data.series) {
            const selected = data.series.find(item => item.id === seriesIdParam);
            if (selected) {
                fillSeriesForm(selected);
            } else {
                resetSeriesForm();
            }
        } else {
            resetSeriesForm();
        }
        if (button) {
            button.addEventListener("click", async () => {
                const formValues = readFormValues([
                    "seriesId",
                    "title",
                    "dayOfWeek",
                    "startTimeLocal",
                    "durationMinutes",
                    "capacity",
                    "priceCents",
                    "instructorId",
                    "roomId",
                    "description",
                    "recurrenceIntervalWeeks",
                    "cancellationWindowHours",
                    "isActive"
                ]);

                const payload = {
                    title: formValues.title,
                    description: formValues.description || "",
                    instructorId: formValues.instructorId || null,
                    roomId: formValues.roomId || null,
                    dayOfWeek: Number(formValues.dayOfWeek),
                    startTimeLocal: `${formValues.startTimeLocal}:00`,
                    durationMinutes: Number(formValues.durationMinutes),
                    recurrenceIntervalWeeks: Number(formValues.recurrenceIntervalWeeks || 1),
                    defaultCapacity: Number(formValues.capacity || 0),
                    priceCents: Number(formValues.priceCents),
                    currency: "USD",
                    cancellationWindowHours: Number(formValues.cancellationWindowHours || 0),
                    isActive: formValues.isActive === "true"
                };

                if (formValues.seriesId) {
                    await apiPut(`/api/admin/event-series/${formValues.seriesId}`, payload);
                } else {
                    await apiPost("/api/admin/event-series", payload);
                }

                resetSeriesForm();
                actor.send({ type: "REFRESH" });
            });
        }

        if (clearButton) {
            clearButton.addEventListener("click", () => {
                resetSeriesForm();
            });
        }

        document.querySelectorAll("button[data-edit]").forEach(btn => {
            btn.addEventListener("click", () => {
                const seriesId = btn.getAttribute("data-edit");
                const selected = (data.series || []).find(item => item.id === seriesId);
                if (!selected) return;
                fillSeriesForm(selected);
            });
        });

        document.querySelectorAll("button[data-generate]").forEach(btn => {
            btn.addEventListener("click", async () => {
                const seriesId = btn.getAttribute("data-generate");
                await apiPost(`/api/admin/event-series/${seriesId}/generate-instances`, {});
                actor.send({ type: "REFRESH" });
            });
        });
    }

    if (route === "plans") {
        const button = document.getElementById("create-plan");
        if (button) {
            button.addEventListener("click", async () => {
                const formValues = readFormValues([
                    "name",
                    "type",
                    "weeklyLimit",
                    "punchCardUses",
                    "priceCents",
                    "currency"
                ]);

                await apiPost("/api/admin/plans", {
                    name: formValues.name,
                    type: formValues.type,
                    weeklyLimit: Number(formValues.weeklyLimit),
                    punchCardUses: Number(formValues.punchCardUses),
                    priceCents: Number(formValues.priceCents),
                    currency: formValues.currency,
                    active: true
                });

                actor.send({ type: "REFRESH" });
            });
        }
    }

    if (route === "customers") {
        resetCustomerForm();
        const saveBtn = document.getElementById("save-customer");
        const clearBtn = document.getElementById("clear-customer");
        const filterBtn = document.getElementById("apply-customer-filters");
        const selectAll = document.getElementById("customers-select-all");
        const bulkEmail = document.getElementById("bulk-email");
        const bulkSms = document.getElementById("bulk-sms");
        const bulkRegister = document.getElementById("bulk-register");
        const customerMap = new Map((data.customers || []).map(customer => [String(customer.id), customer]));

        if (saveBtn) {
            saveBtn.addEventListener("click", async () => {
                const formValues = readFormValues([
                    "customerId",
                    "fullName",
                    "email",
                    "phone",
                    "tagsJson",
                    "isArchived",
                    "password"
                ]);

                if (!formValues.fullName || !formValues.email) {
                    alert("Full name and email are required.");
                    return;
                }

                if (formValues.customerId) {
                    await apiPut(`/api/admin/customers/${formValues.customerId}`, {
                        fullName: formValues.fullName,
                        email: formValues.email,
                        phone: formValues.phone,
                        tagsJson: formValues.tagsJson,
                        isArchived: formValues.isArchived === "true"
                    });
                } else {
                    await apiPost("/api/admin/customers", {
                        fullName: formValues.fullName,
                        email: formValues.email,
                        phone: formValues.phone,
                        tagsJson: formValues.tagsJson,
                        password: formValues.password || null
                    });
                }

                resetCustomerForm();
                actor.send({ type: "REFRESH" });
            });
        }

        if (clearBtn) {
            clearBtn.addEventListener("click", () => {
                resetCustomerForm();
            });
        }

        if (filterBtn) {
            filterBtn.addEventListener("click", () => {
                const searchInput = document.querySelector("[name=\"search\"]");
                const includeArchivedInput = document.querySelector("[name=\"includeArchived\"]");
                const searchValue = searchInput?.value || "";
                const includeArchived = includeArchivedInput?.checked;
                const params = new URLSearchParams();
                if (searchValue) {
                    params.set("search", searchValue);
                }
                if (includeArchived) {
                    params.set("archived", "1");
                }
                const query = params.toString();
                window.location.hash = `#/customers${query ? `?${query}` : ""}`;
            });
        }

        document.querySelectorAll("button[data-edit]").forEach(btn => {
            btn.addEventListener("click", () => {
                const id = btn.getAttribute("data-edit");
                const customer = customerMap.get(String(id));
                if (!customer) return;
                fillCustomerForm(customer);
            });
        });

        document.querySelectorAll("button[data-archive]").forEach(btn => {
            btn.addEventListener("click", async () => {
                const id = btn.getAttribute("data-archive");
                const customer = customerMap.get(String(id));
                if (!customer) return;
                await apiPut(`/api/admin/customers/${id}`, {
                    fullName: customer.fullName,
                    email: customer.email,
                    phone: customer.phone,
                    tagsJson: customer.tagsJson || "[]",
                    isArchived: !customer.isArchived
                });
                actor.send({ type: "REFRESH" });
            });
        });

        const checkboxes = Array.from(document.querySelectorAll("input[data-customer-select]"));
        if (selectAll) {
            selectAll.addEventListener("change", () => {
                checkboxes.forEach(box => {
                    box.checked = selectAll.checked;
                });
            });
        }

        const getSelectedCustomers = () => {
            const selectedIds = checkboxes.filter(box => box.checked).map(box => box.getAttribute("data-customer-select"));
            return selectedIds.map(id => customerMap.get(String(id))).filter(Boolean);
        };

        if (bulkEmail) {
            bulkEmail.addEventListener("click", () => {
                const emails = getSelectedCustomers()
                    .map(customer => customer.email)
                    .filter(email => email);
                if (emails.length === 0) return;
                window.location.href = `mailto:${emails.join(",")}`;
            });
        }

        if (bulkSms) {
            bulkSms.addEventListener("click", () => {
                const phones = getSelectedCustomers()
                    .map(customer => customer.phone)
                    .filter(phone => phone);
                if (phones.length === 0) return;
                window.location.href = `sms:${phones.join(",")}`;
            });
        }

        if (bulkRegister) {
            bulkRegister.addEventListener("click", async () => {
                const selected = getSelectedCustomers();
                if (selected.length === 0) {
                    alert("Select at least one customer.");
                    return;
                }
                await openBulkRegistrationModal(selected, data);
            });
        }
    }

    if (route === "settings") {
        const button = document.getElementById("save-settings");
        if (button) {
            button.addEventListener("click", async () => {
                const formValues = readFormValues([
                    "name",
                    "timezone",
                    "weekStartsOn",
                    "themeJson"
                ]);
                await apiPut("/api/admin/studio", {
                    name: formValues.name,
                    timezone: formValues.timezone,
                    weekStartsOn: Number(formValues.weekStartsOn),
                    themeJson: formValues.themeJson
                });
                actor.send({ type: "REFRESH" });
            });
        }
    }
}

function readFormValues(fields) {
    const values = {};
    fields.forEach((field) => {
        const element = document.querySelector(`[name="${field}"]`);
        values[field] = element ? element.value : "";
    });
    return values;
}

function setFieldValue(name, value) {
    const element = document.querySelector(`[name="${name}"]`);
    if (!element) return;
    element.value = value ?? "";
}

function fillSeriesForm(series) {
    setFieldValue("seriesId", series.id);
    setFieldValue("title", series.title);
    setFieldValue("description", series.description || "");
    setFieldValue("dayOfWeek", series.dayOfWeek);
    setFieldValue("startTimeLocal", (series.startTimeLocal || "18:00").slice(0, 5));
    setFieldValue("durationMinutes", series.durationMinutes);
    setFieldValue("capacity", series.defaultCapacity);
    setFieldValue("priceCents", series.priceCents);
    setFieldValue("instructorId", series.instructorId || "");
    setFieldValue("roomId", series.roomId || "");
    setFieldValue("recurrenceIntervalWeeks", series.recurrenceIntervalWeeks || 1);
    setFieldValue("cancellationWindowHours", series.cancellationWindowHours || 6);
    setFieldValue("isActive", series.isActive ? "true" : "false");
    const saveBtn = document.getElementById("save-series");
    if (saveBtn) {
        saveBtn.textContent = "Update series";
    }
}

function resetSeriesForm() {
    setFieldValue("seriesId", "");
    setFieldValue("title", "Studio Flow");
    setFieldValue("description", "");
    setFieldValue("dayOfWeek", "2");
    setFieldValue("startTimeLocal", "18:00");
    setFieldValue("durationMinutes", "60");
    setFieldValue("capacity", "14");
    setFieldValue("priceCents", "2500");
    setFieldValue("instructorId", "");
    setFieldValue("roomId", "");
    setFieldValue("recurrenceIntervalWeeks", "1");
    setFieldValue("cancellationWindowHours", "6");
    setFieldValue("isActive", "true");
    const saveBtn = document.getElementById("save-series");
    if (saveBtn) {
        saveBtn.textContent = "Create series";
    }
}

function fillCustomerForm(customer) {
    setFieldValue("customerId", customer.id);
    setFieldValue("fullName", customer.fullName);
    setFieldValue("email", customer.email);
    setFieldValue("phone", customer.phone);
    setFieldValue("tagsJson", customer.tagsJson || "[]");
    setFieldValue("isArchived", customer.isArchived ? "true" : "false");
    setFieldValue("password", "");
    const saveBtn = document.getElementById("save-customer");
    if (saveBtn) {
        saveBtn.textContent = "Update customer";
    }
}

function resetCustomerForm() {
    setFieldValue("customerId", "");
    setFieldValue("fullName", "");
    setFieldValue("email", "");
    setFieldValue("phone", "");
    setFieldValue("tagsJson", "[]");
    setFieldValue("isArchived", "false");
    setFieldValue("password", "");
    const saveBtn = document.getElementById("save-customer");
    if (saveBtn) {
        saveBtn.textContent = "Create customer";
    }
}

async function openCalendarEventModal(item, data) {
    const existing = document.getElementById("calendar-modal");
    if (existing) {
        existing.remove();
    }

    const calendarMeta = data.calendar || {};
    const studio = calendarMeta.studio || {};
    const timeZone = studio.timezone || "UTC";

    let roster = [];
    try {
        roster = await apiGet(`/api/admin/event-instances/${item.id}/roster`);
    } catch {
        roster = [];
    }

    const start = new Date(item.startUtc);
    const end = item.endUtc ? new Date(item.endUtc) : null;
    const timeRange = end ? `${formatTimeOnly(start, timeZone)} - ${formatTimeOnly(end, timeZone)}` : formatTimeOnly(start, timeZone);
    const statusValue = normalizeStatus(item.status);

    const rooms = [
        { id: "", name: "Unassigned", selected: !item.roomId },
        ...(data.rooms || []).map(room => ({
            id: room.id,
            name: room.name,
            selected: room.id === item.roomId
        }))
    ];

    const instructors = [
        { id: "", displayName: "Unassigned", selected: !item.instructorId },
        ...(data.instructors || []).map(instructor => ({
            id: instructor.id,
            displayName: instructor.displayName,
            selected: instructor.id === item.instructorId
        }))
    ];

    const statuses = ["Scheduled", "Cancelled"].map(value => ({
        value,
        label: value,
        selected: value === statusValue
    }));

    const rosterRows = roster.map(row => {
        const bookingStatusLabel = normalizeBookingStatus(row.bookingStatus);
        const attendanceLabel = normalizeAttendanceStatus(row.attendanceStatus);
        return {
            ...row,
            bookingStatusLabel,
            attendanceLabel,
            isCancelled: bookingStatusLabel === "Cancelled",
            isRegistered: attendanceLabel === "Registered",
            isPresent: attendanceLabel === "Present",
            isNoShow: attendanceLabel === "No-show"
        };
    });

    const modalMarkup = calendarModalTemplate({
        ...item,
        timeRange,
        startLabel: formatFullDate(start, timeZone),
        statusLabel: statusValue,
        statuses,
        rooms,
        instructors,
        roster: rosterRows,
        customers: (data.customers || []).map(customer => ({
            ...customer,
            email: customer.email || ""
        }))
    });

    const wrapper = document.createElement("div");
    wrapper.innerHTML = modalMarkup;
    const overlay = wrapper.firstElementChild;
    if (!overlay) return;

    document.body.appendChild(overlay);

    const closeModal = () => overlay.remove();
    overlay.addEventListener("click", (event) => {
        if (event.target === overlay) {
            closeModal();
        }
    });

    const closeBtn = overlay.querySelector("#close-modal");
    if (closeBtn) {
        closeBtn.addEventListener("click", closeModal);
    }

    const editSeriesBtn = overlay.querySelector("#edit-series");
    if (editSeriesBtn) {
        editSeriesBtn.addEventListener("click", () => {
            closeModal();
            window.location.hash = `#/events?series=${item.eventSeriesId}`;
        });
    }

    const saveBtn = overlay.querySelector("#save-instance");
    if (saveBtn) {
        saveBtn.addEventListener("click", async () => {
            const formValues = {};
            ["status", "roomId", "instructorId", "capacity", "priceCents"].forEach(field => {
                const element = overlay.querySelector(`[name="${field}"]`);
                formValues[field] = element ? element.value : "";
            });

            await apiPut(`/api/admin/event-instances/${item.id}`, {
                status: formValues.status || statusValue,
                roomId: formValues.roomId || null,
                instructorId: formValues.instructorId || null,
                capacity: Number(formValues.capacity || item.capacity),
                priceCents: Number(formValues.priceCents || item.priceCents),
                currency: item.currency || "USD"
            });

            closeModal();
            actor.send({ type: "REFRESH" });
        });
    }

    overlay.querySelectorAll("select[data-attendance]").forEach(select => {
        select.addEventListener("change", async () => {
            const customerId = select.getAttribute("data-attendance");
            const value = select.value;
            if (!customerId) return;
            if (value === "Registered") {
                await apiDelete(`/api/admin/event-instances/${item.id}/attendance/${customerId}`);
                return;
            }
            await apiPost(`/api/admin/event-instances/${item.id}/attendance`, {
                customerId,
                status: value
            });
        });
    });

    const rosterCheckboxes = Array.from(overlay.querySelectorAll("input[data-roster-select]"));
    const rosterSelectAll = overlay.querySelector("#roster-select-all");
    const rosterEmailBtn = overlay.querySelector("#roster-email");
    const rosterSmsBtn = overlay.querySelector("#roster-sms");

    if (rosterSelectAll) {
        rosterSelectAll.addEventListener("change", () => {
            rosterCheckboxes.forEach(box => {
                box.checked = rosterSelectAll.checked;
            });
        });
    }

    const getSelectedRoster = () => {
        const selectedIds = rosterCheckboxes
            .filter(box => box.checked)
            .map(box => box.getAttribute("data-roster-select"));
        return rosterRows.filter(row => selectedIds.includes(row.customerId));
    };

    if (rosterEmailBtn) {
        rosterEmailBtn.addEventListener("click", () => {
            const emails = getSelectedRoster()
                .map(row => row.email)
                .filter(email => email);
            if (emails.length === 0) return;
            window.location.href = `mailto:${emails.join(",")}`;
        });
    }

    if (rosterSmsBtn) {
        rosterSmsBtn.addEventListener("click", () => {
            const phones = getSelectedRoster()
                .map(row => row.phone)
                .filter(phone => phone);
            if (phones.length === 0) return;
            window.location.href = `sms:${phones.join(",")}`;
        });
    }

    const registerBtn = overlay.querySelector("#register-customer");
    if (registerBtn) {
        registerBtn.addEventListener("click", async () => {
            const getValue = (name) => overlay.querySelector(`[name="${name}"]`)?.value || "";
            const customerId = getValue("customerId");
            const customerIdsSelect = overlay.querySelector("[name=\"customerIds\"]");
            const selectedCustomers = customerIdsSelect
                ? Array.from(customerIdsSelect.selectedOptions).map(option => option.value).filter(value => value)
                : [];
            const fullName = getValue("fullName");
            const email = getValue("email");
            const phone = getValue("phone");

            if (!customerId && selectedCustomers.length === 0 && (!fullName || !email)) {
                alert("Select a customer or enter name and email.");
                return;
            }

            if (selectedCustomers.length > 0) {
                await Promise.all(selectedCustomers.map(id => apiPost(`/api/admin/event-instances/${item.id}/registrations`, {
                    customerId: id,
                    fullName: "",
                    email: "",
                    phone: "",
                    membershipId: null
                })));
            } else {
                await apiPost(`/api/admin/event-instances/${item.id}/registrations`, {
                    customerId: customerId || null,
                    fullName,
                    email,
                    phone,
                    membershipId: null
                });
            }

            closeModal();
            actor.send({ type: "REFRESH" });
        });
    }
}

function openSessionModal(data) {
    const existing = document.getElementById("session-modal");
    if (existing) {
        existing.remove();
    }

    const calendarMeta = data.calendar || {};
    const focusDate = calendarMeta.focusDate || toDateInputValue(new Date());
    const modalMarkup = sessionModalTemplate({
        focusDate,
        rooms: data.rooms || [],
        instructors: data.instructors || []
    });

    const wrapper = document.createElement("div");
    wrapper.innerHTML = modalMarkup;
    const overlay = wrapper.firstElementChild;
    if (!overlay) return;

    document.body.appendChild(overlay);

    const closeModal = () => overlay.remove();
    overlay.addEventListener("click", (event) => {
        if (event.target === overlay) {
            closeModal();
        }
    });

    const closeBtn = overlay.querySelector("#close-session");
    if (closeBtn) {
        closeBtn.addEventListener("click", closeModal);
    }

    const typeSelect = overlay.querySelector("[name=\"sessionType\"]");
    const oneTimeSection = overlay.querySelector(".session-one-time");
    const recurringSection = overlay.querySelector(".session-recurring");

    const setMode = (mode) => {
        const isRecurring = mode === "recurring";
        if (oneTimeSection) oneTimeSection.classList.toggle("hidden", isRecurring);
        if (recurringSection) recurringSection.classList.toggle("hidden", !isRecurring);
    };

    if (typeSelect) {
        typeSelect.addEventListener("change", () => {
            setMode(typeSelect.value);
        });
    }

    const saveBtn = overlay.querySelector("#save-session");
    if (saveBtn) {
        saveBtn.addEventListener("click", async () => {
            const getValue = (name) => overlay.querySelector(`[name="${name}"]`)?.value || "";
            const type = getValue("sessionType") || "one-time";
            const payload = {
                title: getValue("title"),
                description: getValue("description"),
                instructorId: getValue("instructorId") || null,
                roomId: getValue("roomId") || null,
                startTimeLocal: `${getValue("startTimeLocal")}:00`,
                durationMinutes: Number(getValue("durationMinutes") || 0),
                capacity: Number(getValue("capacity") || 0),
                priceCents: Number(getValue("priceCents") || 0),
                currency: getValue("currency") || "USD",
                cancellationWindowHours: Number(getValue("cancellationWindowHours") || 0)
            };

            if (!payload.title || !payload.startTimeLocal || payload.durationMinutes <= 0) {
                alert("Title, time, and duration are required.");
                return;
            }

            try {
                if (type === "recurring") {
                    const startDate = getValue("startDate") || focusDate;
                    const dayOfWeek = Number(getValue("dayOfWeek"));
                    const recurrenceIntervalWeeks = Number(getValue("recurrenceIntervalWeeks") || 1);
                    const generateWeeks = Number(getValue("generateWeeks") || 8);

                    const series = await apiPost("/api/admin/event-series", {
                        title: payload.title,
                        description: payload.description || "",
                        instructorId: payload.instructorId,
                        roomId: payload.roomId,
                        dayOfWeek,
                        startTimeLocal: payload.startTimeLocal,
                        durationMinutes: payload.durationMinutes,
                        recurrenceIntervalWeeks,
                        defaultCapacity: payload.capacity,
                        priceCents: payload.priceCents,
                        currency: payload.currency,
                        cancellationWindowHours: payload.cancellationWindowHours,
                        isActive: true
                    });

                    const toDate = new Date(startDate);
                    toDate.setDate(toDate.getDate() + generateWeeks * 7);
                    const to = toDateInputValue(toDate);
                    await apiPost(`/api/admin/event-series/${series.id}/generate-instances?from=${startDate}&to=${to}`, {});
                } else {
                    const date = getValue("date") || focusDate;
                    await apiPost("/api/admin/event-instances", {
                        title: payload.title,
                        description: payload.description || "",
                        date,
                        startTimeLocal: payload.startTimeLocal,
                        durationMinutes: payload.durationMinutes,
                        instructorId: payload.instructorId,
                        roomId: payload.roomId,
                        capacity: payload.capacity,
                        priceCents: payload.priceCents,
                        currency: payload.currency,
                        cancellationWindowHours: payload.cancellationWindowHours,
                        status: "Scheduled"
                    });
                }

                closeModal();
                actor.send({ type: "REFRESH" });
            } catch (error) {
                alert(error.message);
            }
        });
    }

    setMode("one-time");
}

async function openBulkRegistrationModal(selectedCustomers, data) {
    const existing = document.getElementById("bulk-registration-modal");
    if (existing) {
        existing.remove();
    }

    const calendarMeta = data.calendar || {};
    const studio = calendarMeta.studio || {};
    const timeZone = studio.timezone || "UTC";
    const from = toDateInputValue(new Date());
    const toDate = new Date();
    toDate.setDate(toDate.getDate() + 14);
    const to = toDateInputValue(toDate);
    const sessions = await apiGet(`/api/admin/calendar?from=${from}&to=${to}`);

    const sessionOptions = (sessions || []).map(item => {
        const start = new Date(item.startUtc);
        const label = `${item.seriesTitle} - ${formatMonthDay(start, timeZone)} ${formatTimeOnly(start, timeZone)}`;
        return { id: item.id, label };
    });

    const modalMarkup = bulkRegistrationTemplate({
        count: selectedCustomers.length,
        sessions: sessionOptions
    });

    const wrapper = document.createElement("div");
    wrapper.innerHTML = modalMarkup;
    const overlay = wrapper.firstElementChild;
    if (!overlay) return;

    document.body.appendChild(overlay);

    const closeModal = () => overlay.remove();
    overlay.addEventListener("click", (event) => {
        if (event.target === overlay) {
            closeModal();
        }
    });

    const closeBtn = overlay.querySelector("#close-bulk-registration");
    if (closeBtn) {
        closeBtn.addEventListener("click", closeModal);
    }

    const confirmBtn = overlay.querySelector("#confirm-bulk-registration");
    if (confirmBtn) {
        confirmBtn.addEventListener("click", async () => {
            const sessionId = overlay.querySelector("[name=\"sessionId\"]")?.value;
            if (!sessionId) return;
            await Promise.all(selectedCustomers.map(customer => apiPost(`/api/admin/event-instances/${sessionId}/registrations`, {
                customerId: customer.id,
                fullName: "",
                email: "",
                phone: "",
                membershipId: null
            })));
            closeModal();
            actor.send({ type: "REFRESH" });
        });
    }
}

function getCalendarRange(view, focusDate, weekStartsOn) {
    const focus = parseDateInput(focusDate);
    const safeWeekStart = Number.isFinite(Number(weekStartsOn)) ? Number(weekStartsOn) : 0;

    if (view === "day") {
        const nextDay = addDays(focus, 1);
        return { from: formatDateKeyLocal(focus), to: formatDateKeyLocal(nextDay) };
    }

    if (view === "month") {
        const firstOfMonth = new Date(focus.getFullYear(), focus.getMonth(), 1, 12);
        const gridStart = startOfWeek(firstOfMonth, safeWeekStart);
        const gridEnd = addDays(gridStart, 42);
        return { from: formatDateKeyLocal(gridStart), to: formatDateKeyLocal(gridEnd) };
    }

    const start = startOfWeek(focus, safeWeekStart);
    const end = addDays(start, 7);
    return { from: formatDateKeyLocal(start), to: formatDateKeyLocal(end) };
}

function buildCalendarView(items, options) {
    const view = options.view || "week";
    const focusDate = options.focusDate || toDateInputValue(new Date());
    const timeZone = options.timeZone || "UTC";
    const weekStartsOn = Number.isFinite(Number(options.weekStartsOn))
        ? Number(options.weekStartsOn)
        : 0;
    const eventMap = buildEventMap(items, timeZone);
    const todayKey = getDateKeyInTimeZone(new Date(), timeZone);

    const dayDate = parseDateInput(focusDate);
    const dayKey = formatDateKeyLocal(dayDate);
    const dayEvents = eventMap.get(dayKey) || [];
    const day = {
        label: formatFullDate(dayDate, timeZone),
        events: dayEvents,
        hasEvents: dayEvents.length > 0
    };

    const weekStart = startOfWeek(parseDateInput(focusDate), weekStartsOn);
    const weekdayNames = getWeekdayNames(weekStartsOn);
    const weekDays = [];
    for (let i = 0; i < 7; i += 1) {
        const date = addDays(weekStart, i);
        const key = formatDateKeyLocal(date);
        const events = eventMap.get(key) || [];
        weekDays.push({
            dateKey: key,
            weekday: weekdayNames[i],
            dateLabel: formatMonthDay(date, timeZone),
            events,
            hasEvents: events.length > 0,
            isToday: key === todayKey
        });
    }

    const focus = parseDateInput(focusDate);
    const firstOfMonth = new Date(focus.getFullYear(), focus.getMonth(), 1, 12);
    const gridStart = startOfWeek(firstOfMonth, weekStartsOn);
    const monthWeeks = [];
    for (let w = 0; w < 6; w += 1) {
        const days = [];
        for (let d = 0; d < 7; d += 1) {
            const date = addDays(gridStart, w * 7 + d);
            const key = formatDateKeyLocal(date);
            const events = eventMap.get(key) || [];
            const previews = events.slice(0, 3).map(event => ({
                id: event.id,
                time: event.startTime,
                title: event.seriesTitle,
                isCancelled: event.isCancelled
            }));
            days.push({
                label: date.getDate(),
                isCurrentMonth: date.getMonth() === focus.getMonth(),
                isToday: key === todayKey,
                eventsPreview: previews,
                moreCount: Math.max(0, events.length - previews.length),
                hasEvents: events.length > 0
            });
        }
        monthWeeks.push({ days });
    }

    const rangeLabel = getRangeLabel(view, focusDate, weekStartsOn, timeZone);

    return {
        view,
        focusDate,
        rangeLabel,
        isDay: view === "day",
        isWeek: view === "week",
        isMonth: view === "month",
        day,
        week: { days: weekDays },
        month: { weeks: monthWeeks, weekdays: weekdayNames }
    };
}

function normalizeStatus(value) {
    if (typeof value === "string") {
        return value;
    }
    return value === 1 ? "Cancelled" : "Scheduled";
}

function normalizeBookingStatus(value) {
    if (typeof value === "string") {
        if (value === "Confirmed") {
            return "Registered";
        }
        return value;
    }
    if (value === 2) {
        return "Cancelled";
    }
    if (value === 1) {
        return "Registered";
    }
    return "Pending";
}

function normalizeAttendanceStatus(value) {
    if (typeof value === "string") {
        return value === "NoShow" ? "No-show" : value;
    }
    if (value === 0) {
        return "Present";
    }
    if (value === 1) {
        return "No-show";
    }
    return "Registered";
}

function buildEventMap(items, timeZone) {
    const map = new Map();
    items.forEach(item => {
        const start = new Date(item.startUtc);
        const end = item.endUtc ? new Date(item.endUtc) : null;
        const dateKey = getDateKeyInTimeZone(start, timeZone);
        const startTime = formatTimeOnly(start, timeZone);
        const endTime = end ? formatTimeOnly(end, timeZone) : "";
        const timeRange = endTime ? `${startTime} - ${endTime}` : startTime;
        const statusLabel = normalizeStatus(item.status);
        const event = {
            ...item,
            dateKey,
            startTime,
            endTime,
            timeRange,
            statusLabel,
            isCancelled: statusLabel === "Cancelled",
            price: formatMoney(item.priceCents, item.currency)
        };
        const list = map.get(dateKey) || [];
        list.push(event);
        map.set(dateKey, list);
    });

    map.forEach(list => list.sort((a, b) => new Date(a.startUtc) - new Date(b.startUtc)));
    return map;
}

function getRangeLabel(view, focusDate, weekStartsOn, timeZone) {
    const focus = parseDateInput(focusDate);

    if (view === "day") {
        return formatFullDate(focus, timeZone);
    }

    if (view === "month") {
        return formatMonthYear(focus, timeZone);
    }

    const weekStart = startOfWeek(focus, weekStartsOn);
    const weekEnd = addDays(weekStart, 6);
    return `${formatMonthDay(weekStart, timeZone)} - ${formatMonthDay(weekEnd, timeZone)}`;
}

function shiftCalendarDate(view, focusDate, direction) {
    const focus = parseDateInput(focusDate);

    if (view === "day") {
        return formatDateKeyLocal(addDays(focus, direction));
    }

    if (view === "month") {
        const next = new Date(focus.getFullYear(), focus.getMonth() + direction, 1, 12);
        return formatDateKeyLocal(next);
    }

    return formatDateKeyLocal(addDays(focus, direction * 7));
}

function parseDateInput(value) {
    if (!value) {
        const now = new Date();
        now.setHours(12, 0, 0, 0);
        return now;
    }
    const [year, month, day] = value.split("-").map(Number);
    return new Date(year, (month || 1) - 1, day || 1, 12);
}

function formatDateKeyLocal(date) {
    const year = date.getFullYear();
    const month = String(date.getMonth() + 1).padStart(2, "0");
    const day = String(date.getDate()).padStart(2, "0");
    return `${year}-${month}-${day}`;
}

function getDateKeyInTimeZone(value, timeZone) {
    const date = value instanceof Date ? value : new Date(value);
    const formatter = new Intl.DateTimeFormat("en-US", {
        timeZone,
        year: "numeric",
        month: "2-digit",
        day: "2-digit"
    });
    const parts = formatter.formatToParts(date);
    const year = parts.find(part => part.type === "year")?.value ?? "0000";
    const month = parts.find(part => part.type === "month")?.value ?? "01";
    const day = parts.find(part => part.type === "day")?.value ?? "01";
    return `${year}-${month}-${day}`;
}

function startOfWeek(date, weekStartsOn) {
    const dayIndex = date.getDay();
    const diff = (dayIndex - weekStartsOn + 7) % 7;
    return addDays(date, -diff);
}

function addDays(date, amount) {
    const next = new Date(date);
    next.setDate(next.getDate() + amount);
    return next;
}

function formatTimeOnly(date, timeZone) {
    return new Intl.DateTimeFormat("en-US", {
        timeZone,
        hour: "numeric",
        minute: "2-digit"
    }).format(date);
}

function formatMonthDay(date, timeZone) {
    return new Intl.DateTimeFormat("en-US", {
        timeZone,
        month: "short",
        day: "numeric"
    }).format(date);
}

function formatFullDate(date, timeZone) {
    return new Intl.DateTimeFormat("en-US", {
        timeZone,
        weekday: "long",
        month: "long",
        day: "numeric",
        year: "numeric"
    }).format(date);
}

function formatMonthYear(date, timeZone) {
    return new Intl.DateTimeFormat("en-US", {
        timeZone,
        month: "long",
        year: "numeric"
    }).format(date);
}

function getWeekdayNames(weekStartsOn) {
    const names = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];
    const rotated = names.slice(weekStartsOn).concat(names.slice(0, weekStartsOn));
    return rotated;
}

actor.subscribe((state) => {
    render(state);
});

actor.start();

const adminRoutes = new Set(["calendar", "events", "plans", "customers", "reports", "settings"]);

function resolveRouteFromHash(defaultRoute) {
    const hash = window.location.hash || `#/${defaultRoute}`;
    const cleaned = hash.replace(/^#\/?/, "");
    const route = cleaned.split("/")[0] || defaultRoute;
    return adminRoutes.has(route) ? route : defaultRoute;
}

function handleRouteChange() {
    const route = resolveRouteFromHash("calendar");
    actor.send({ type: "NAVIGATE", route });
}

window.addEventListener("hashchange", handleRouteChange);
handleRouteChange();





